const textInput = document.getElementById("textInput");
const charCount = document.getElementById("charCount");
const analyzeBtn = document.getElementById("analyzeBtn");

const emotionResult = document.getElementById("emotionResult");
const emotionIcon = document.getElementById("emotionIcon");
const confidenceValue = document.getElementById("confidenceValue");
const progressFill = document.getElementById("progressFill");


// Character Counter
textInput.addEventListener("input", function () {

    const length = textInput.value.length;

    charCount.textContent = `${length} / 500`;

});


// Emotion Keywords
const emotions = {

    Joy: {
        words: [
            "happy",
            "happiness",
            "joy",
            "excited",
            "exciting",
            "love",
            "loving",
            "great",
            "amazing",
            "awesome",
            "wonderful",
            "glad",
            "celebrate",
            "celebration",
            "smile",
            "smiling",
            "fun",
            "enjoy",
            "enjoying"
        ],
        icon: "😊"
    },

    Sadness: {
        words: [
            "sad",
            "sadness",
            "cry",
            "crying",
            "lonely",
            "alone",
            "unhappy",
            "hurt",
            "pain",
            "depressed",
            "miss",
            "missing",
            "heartbroken",
            "disappointed"
        ],
        icon: "😢"
    },

    Anger: {
        words: [
            "angry",
            "anger",
            "mad",
            "hate",
            "hating",
            "furious",
            "annoyed",
            "annoying",
            "rage",
            "fight",
            "fighting",
            "stupid",
            "worst"
        ],
        icon: "😡"
    },

    Fear: {
        words: [
            "fear",
            "afraid",
            "scared",
            "scary",
            "terrified",
            "terror",
            "worried",
            "worry",
            "danger",
            "dangerous",
            "nervous",
            "anxious"
        ],
        icon: "😨"
    },

    Surprise: {
        words: [
            "wow",
            "surprise",
            "surprised",
            "shocked",
            "shock",
            "unexpected",
            "unbelievable",
            "omg",
            "suddenly"
        ],
        icon: "😲"
    },

    Love: {
        words: [
            "love",
            "loved",
            "lovely",
            "romantic",
            "kiss",
            "care",
            "caring",
            "dear",
            "darling",
            "beautiful"
        ],
        icon: "❤️"
    },

    Neutral: {
        words: [
            "okay",
            "ok",
            "fine",
            "normal",
            "today",
            "weather",
            "information",
            "update",
            "post"
        ],
        icon: "😐"
    }

};


// Analyze Emotion
analyzeBtn.addEventListener("click", function () {

    const text = textInput.value.trim().toLowerCase();

    if (text === "") {

        emotionResult.textContent = "Please enter some text";
        emotionIcon.textContent = "⚠️";

        confidenceValue.textContent = "0%";
        progressFill.style.width = "0%";

        return;
    }


    const words = text.match(/\b[\w']+\b/g) || [];

    let scores = {};

    Object.keys(emotions).forEach(emotion => {
        scores[emotion] = 0;
    });


    // Count matching emotion words
    words.forEach(word => {

        Object.keys(emotions).forEach(emotion => {

            if (emotions[emotion].words.includes(word)) {
                scores[emotion]++;
            }

        });

    });


    // Find highest score
    let detectedEmotion = "Neutral";
    let highestScore = 0;

    Object.keys(scores).forEach(emotion => {

        if (scores[emotion] > highestScore) {

            highestScore = scores[emotion];
            detectedEmotion = emotion;

        }

    });


    // Calculate confidence
    let confidence;

    if (highestScore === 0) {

        confidence = 50;

    } else {

        const totalWords = words.length;

        confidence = Math.round(
            Math.min(
                95,
                65 + (highestScore / totalWords) * 35
            )
        );

    }


    // Display Result
    emotionResult.textContent = detectedEmotion;

    emotionIcon.textContent = emotions[detectedEmotion].icon;

    confidenceValue.textContent = `${confidence}%`;

    progressFill.style.width = `${confidence}%`;

});